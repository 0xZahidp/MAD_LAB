package com.example.madlab

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
